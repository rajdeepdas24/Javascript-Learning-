function addLanguage(langname){
    const li = document.createElement('li')
    li.innerHTML = `${langname}`
    document.querySelector('.languages').appendChild(li)
} // nnot optimised! Innerhtml traverse the whole element so not good for multiple nodes 
addLanguage("python")
addLanguage("typescript")

function opti(langname) {
    const li = document.createElement('li');
    li.appendChild(document.createTextNode(langname));
    document.querySelector('.languages').appendChild(li);
} // preferred most in projects

opti('MongoDB');



//  EDIT

const secondlang = document.querySelector("li:nth-child(2)")
// secondlang.innerHTML = "MOJO"
const newli = document.createElement("li")
newli.textContent = "Mojo"
secondlang.replaceWith(newli)


const thirdlang = document.querySelector("li:nth-child(1)")
// thirdlang.innerHTML = "MOJO"
const myli = document.createElement("li")
myli.textContent = "typescirpt"
thirdlang.replaceWith(myli)

// remove

const lastlang = document.querySelector('li:last-child')
lastlang.remove()



// ________________________________________________________________________________________________________________




/*

DOM Manipulation (Add, Edit and Remove Elements)
_________________________________________________________

Definition

DOM Manipulation is the process of creating, updating and deleting HTML elements dynamically using JavaScript.

_________________________________________________________

Adding Elements

Elements can be created using

createElement()

and inserted into the DOM using

appendChild()

_________________________________________________________

innerHTML

Used to insert HTML content inside an element.

Features

• Parses HTML.

• Can insert HTML tags.

• Re-parses the content of the element.

• Less efficient when updating multiple elements.

_________________________________________________________

createTextNode()

Creates a plain text node.

Features

• Does not parse HTML.

• More efficient for plain text.

• Preferred in real-world projects.

_________________________________________________________

textContent

Sets or returns the text content of an element.

Features

• Inserts plain text.

• Ignores HTML tags.

• Faster than innerHTML for text updates.

_________________________________________________________

Editing Elements

Existing elements can be modified using

• textContent

• innerHTML

• replaceWith()

_________________________________________________________

replaceWith()

Replaces an existing element with another element.

The old element is removed from the DOM.

_________________________________________________________

Removing Elements

remove()

Removes the selected element from the DOM.

No parent element is required.

_________________________________________________________

Difference Between
innerHTML and textContent

innerHTML

• Reads and writes HTML.

• Parses HTML tags.

----------------------------

textContent

• Reads and writes only text.

• Does not parse HTML.

• Better for plain text.

_________________________________________________________

Difference Between
innerHTML and createTextNode()

innerHTML

• Parses HTML.

• Recreates the element's content.

• Slower for repeated updates.

----------------------------

createTextNode()

• Creates only text.

• Does not parse HTML.

• More efficient.

• Preferred in production projects.

_________________________________________________________

Summary

✔ createElement() creates an element.

✔ appendChild() inserts the element.

✔ innerHTML inserts HTML.

✔ textContent inserts text.

✔ createTextNode() creates a text node.

✔ replaceWith() replaces an element.

✔ remove() deletes an element.

✔ createTextNode() is preferred for plain text.

_________________________________________________________

Interview Questions

Q1. What is DOM Manipulation?

Ans:

The process of creating, updating and deleting HTML elements using JavaScript.

----------------------------

Q2. Difference between innerHTML and textContent?

Ans:

innerHTML

Works with HTML.

textContent

Works only with text.

----------------------------

Q3. Why is createTextNode() preferred over innerHTML?

Ans:

Because it creates plain text without parsing HTML, making it more efficient and safer for text insertion.

----------------------------

Q4. What does replaceWith() do?

Ans:

Replaces an existing DOM element with another element.

----------------------------

Q5. What does remove() do?

Ans:

Deletes the selected element from the DOM.

----------------------------

Q6. Difference between textContent and createTextNode()?

Ans:

textContent

Sets or changes the text of an existing element.

createTextNode()

Creates a new text node that can be attached to an element.

----------------------------

Q7. Which method is preferred in production projects for adding plain text?

Ans:

createTextNode()

_________________________________________________________

Easy Trick

createElement()

↓

Create

----------------------------

appendChild()

↓

Insert

----------------------------

textContent

↓

Update Text

----------------------------

replaceWith()

↓

Replace

----------------------------

remove()

↓

Delete

*/
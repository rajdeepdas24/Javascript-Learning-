// const title = document.getElementById('title')    

// title.style.backgroundColor = 'orange'

// title.innerText  
// title.innerHTML  
// title.textContent


// document.querySelector("h1")
// document.querySelector("#title")
// document.querySelector(".heading")

// const myul = document.querySelector("ul")
// const myli = myul.querySelector("li")

// myli.style.backgroundColor = "Brown"
// myli.style.color = 'lightpink'

// myli.innerText = "nine"

// const templilist = document.querySelectorAll('li')
// templilist[1].style.color = "yellow"
// templilist.forEach(  (list) => list.style.backgroundColor = "red" )

// const myh1 = document.querySelectorAll("h1")
// myh1[3].style.color = "blue"

// const listeditems = document.getElementsByClassName("list-items")

// const arrlist = Array.from(listeditems)

// arrlist.forEach( (l) => l.style.color = "green")



//________________________________________________________________________________________




/*

DOM (Document Object Model)
_________________________________________________________

Definition

The DOM is a programming interface for HTML and XML documents.

It represents the entire webpage as a tree of objects, allowing JavaScript to access, modify and manipulate HTML elements dynamically.

_________________________________________________________

Common DOM Selectors

1. getElementById()

Selects an element using its id.

Returns

• A single Element.
• Returns null if the id does not exist.

Syntax

document.getElementById("idName")

_________________________________________________________

2. getElementsByClassName()

Selects all elements having the specified class.

Returns

• HTMLCollection

Syntax

document.getElementsByClassName("className")

_________________________________________________________

3. getElementsByTagName()

Selects all elements with the specified tag.

Returns

• HTMLCollection

Syntax

document.getElementsByTagName("h1")

_________________________________________________________

4. querySelector()

Selects the FIRST element matching a CSS selector.

Returns

• Single Element

Syntax

document.querySelector("selector")

Selectors can be

• id (#id)

• class (.class)

• tag (h1)

• attribute ([type="text"])

_________________________________________________________

5. querySelectorAll()

Selects ALL matching elements.

Returns

• NodeList

Syntax

document.querySelectorAll("selector")

_________________________________________________________

NodeList
_________________________________________________________

Definition

A NodeList is a collection of DOM nodes returned by methods like

querySelectorAll()

It can contain

• Elements

• Text Nodes

• Comments

depending on how it is created.

_________________________________________________________

Features of NodeList

✔ Supports

forEach()

✔ Can be accessed using indexes.

✔ Has a length property.

✔ Can be converted into an Array.

_________________________________________________________

HTMLCollection
_________________________________________________________

Definition

An HTMLCollection is a collection of HTML Elements returned by methods like

getElementsByClassName()

getElementsByTagName()

_________________________________________________________

Features of HTMLCollection

✔ Contains only HTML Elements.

✔ Can be accessed using indexes.

✔ Has a length property.

✘ Does NOT support

forEach()

directly.

✔ Can be converted into an Array.

_________________________________________________________

Difference Between
NodeList and HTMLCollection

NodeList

✔ Returned by querySelectorAll()

✔ Supports forEach()

✔ Can contain different types of nodes.

----------------------------

HTMLCollection

✔ Returned by

getElementsByClassName()

getElementsByTagName()

✔ Contains only HTML Elements.

✘ Does not support forEach() directly.

_________________________________________________________

Difference Between
querySelector() and querySelectorAll()

querySelector()

✔ Returns only the first matching element.

----------------------------

querySelectorAll()

✔ Returns all matching elements as a NodeList.

_________________________________________________________

Difference Between
getElementById() and querySelector()

getElementById()

✔ Selects only by id.

✔ Faster.

----------------------------

querySelector()

✔ Uses any CSS selector.

✔ More flexible.

_________________________________________________________

Converting HTMLCollection to Array

Use

Array.from()

This allows the use of array methods like

• map()

• filter()

• forEach()

_________________________________________________________

Summary

✔ DOM represents the webpage as objects.

✔ getElementById() returns one element.

✔ getElementsByClassName() returns HTMLCollection.

✔ getElementsByTagName() returns HTMLCollection.

✔ querySelector() returns the first matching element.

✔ querySelectorAll() returns a NodeList.

✔ NodeList supports forEach().

✔ HTMLCollection does not support forEach() directly.

✔ Array.from() converts HTMLCollection into an Array.

_________________________________________________________

Interview Questions

Q1. What is DOM?

Ans:

The Document Object Model is a programming interface that represents an HTML document as a tree of objects.

----------------------------

Q2. Difference between NodeList and HTMLCollection?

Ans:

NodeList

Supports forEach().

Can contain different node types.

HTMLCollection

Contains only HTML elements.

Does not support forEach() directly.

----------------------------

Q3. Difference between querySelector() and querySelectorAll()?

Ans:

querySelector()

Returns the first matching element.

querySelectorAll()

Returns all matching elements as a NodeList.

----------------------------

Q4. Which methods return HTMLCollection?

Ans:

getElementsByClassName()

getElementsByTagName()

----------------------------

Q5. Which method returns a NodeList?

Ans:

querySelectorAll()

----------------------------

Q6. Which selector is fastest?

Ans:

getElementById()

because it directly searches using the unique id.

----------------------------

Q7. Can we use forEach() on HTMLCollection?

Ans:

No.

Convert it using

Array.from()

or use a normal loop.

----------------------------

Q8. Can we use CSS selectors with querySelector()?

Ans:

Yes.

It accepts all valid CSS selectors.

_________________________________________________________

Easy Trick

getElementById()

↓

One Element

----------------------------

getElementsByClassName()

↓

HTMLCollection

----------------------------

getElementsByTagName()

↓

HTMLCollection

----------------------------

querySelector()

↓

First Match

----------------------------

querySelectorAll()

↓

NodeList

----------------------------

NodeList

✔ forEach()

----------------------------

HTMLCollection

✘ forEach()

*/























// ______________________________________________________________________________________











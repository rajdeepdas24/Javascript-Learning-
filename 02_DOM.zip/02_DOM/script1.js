const div = document.createElement('div')
console.log(div);
div.className = "main"
// div.myid = "myid"
div.id =  "1"
div.setAttribute("title", "Generate title")
div.style.backgroundColor = "Blue"
const addtext = document.createTextNode("Chai aur Code")
div.appendChild(addtext)

document.body.appendChild(div)



// _________________________________________________________________


/*

Creating DOM Elements
_________________________________________________________

Definition

JavaScript allows us to create, modify and add HTML elements dynamically without writing them directly in the HTML file.

_________________________________________________________

document.createElement()

Creates a new HTML element.

The element is created in memory and is NOT visible on the webpage until it is added to the DOM.

_________________________________________________________

className

Used to assign a class to an element.

It is equivalent to the HTML class attribute.

_________________________________________________________

id

Used to assign a unique id to an element.

It is equivalent to the HTML id attribute.

_________________________________________________________

setAttribute()

Adds a new attribute or updates an existing attribute of an element.

It is commonly used for attributes such as

• title

• href

• src

• alt

• id

• class

_________________________________________________________

style

Used to apply inline CSS styles using JavaScript.

Each CSS property becomes a JavaScript property.

Example

background-color

becomes

backgroundColor

_________________________________________________________

createTextNode()

Creates a text node.

The text is created in memory and must be added to an element before it appears on the webpage.

_________________________________________________________

appendChild()

Adds a child node to the end of the selected parent element.

It is commonly used to add

• Elements

• Text Nodes

_________________________________________________________

document.body.appendChild()

Appends the created element to the end of the <body> element.

Only after this step does the element become visible on the webpage.

_________________________________________________________

Difference Between

innerHTML

and

createTextNode()

innerHTML

• Parses HTML.

• Can insert HTML tags.

----------------------------

createTextNode()

• Creates only plain text.

• HTML tags are treated as normal text.

• Safer against HTML injection.

_________________________________________________________

Difference Between

setAttribute()

and

Direct Property Assignment

setAttribute()

• Creates or updates any attribute.

----------------------------

Direct Assignment

• Modifies element properties directly.

Example

className

id

_________________________________________________________

Summary

✔ createElement() creates a new element.

✔ className sets the class.

✔ id sets the id.

✔ setAttribute() adds or updates attributes.

✔ style applies inline CSS.

✔ createTextNode() creates text.

✔ appendChild() inserts the node into another element.

✔ document.body.appendChild() displays the element on the webpage.

_________________________________________________________

Interview Questions

Q1. What does document.createElement() do?

Ans:

Creates a new HTML element in memory.

----------------------------

Q2. Does createElement() display the element immediately?

Ans:

No.

The element must be appended to the DOM.

----------------------------

Q3. What does appendChild() do?

Ans:

Adds a child node to the end of a parent element.

----------------------------

Q4. What is the difference between createTextNode() and innerHTML?

Ans:

createTextNode()

Creates plain text.

innerHTML

Parses HTML.

----------------------------

Q5. What is setAttribute() used for?

Ans:

To add or update HTML attributes.

----------------------------

Q6. What is className used for?

Ans:

To assign a CSS class to an element.

----------------------------

Q7. Why do we use createTextNode()?

Ans:

To safely create and insert text without parsing it as HTML.

_________________________________________________________

Easy Trick

createElement()

↓

Create Element

----------------------------

createTextNode()

↓

Create Text

----------------------------

appendChild()

↓

Attach Element

----------------------------

body.appendChild()

↓

Display on Webpage

*/
const parent = document.querySelector('.parent')
console.log(parent)
console.log(parent.children[1].innerHTML)

for (let i = 0; i < parent.children.length; i++) {
    console.log(parent.children[i].innerHTML);
}

parent.children[1].style.color = "orange"

console.log(parent.firstElementChild.innerHTML);
console.log(parent.lastElementChild.innerHTML);

const dayone = document.querySelector('.day')
console.log(dayone);
console.log(dayone.parentElement);
console.log(dayone.nextElementSibling);

console.log("NODES : ", parent.childNodes);



// _________________________________________________________________




/*

DOM Traversal
_________________________________________________________

Definition

DOM Traversal is the process of navigating between the elements (nodes) of an HTML document using JavaScript.

It allows us to move from parent to child, child to parent, and between sibling elements.

_________________________________________________________

children

Returns all direct child elements of the selected parent.

• Returns an HTMLCollection.
• Can be accessed using indexes.
• Does not include text nodes.

_________________________________________________________

length

Returns the total number of child elements.

Often used while looping through children.

_________________________________________________________

firstElementChild

Returns the first child element of the parent.

_________________________________________________________

lastElementChild

Returns the last child element of the parent.

_________________________________________________________

parentElement

Returns the parent element of the selected element.

Used to move upward in the DOM tree.

_________________________________________________________

nextElementSibling

Returns the next sibling element of the current element.

If there is no next sibling,
it returns null.

_________________________________________________________

childNodes

Returns all child nodes of an element.

Includes

• Element Nodes

• Text Nodes (Spaces/New Lines)

• Comment Nodes

Returns a NodeList.

_________________________________________________________

Difference between children and childNodes

children

• Returns only HTML elements.

• Returns an HTMLCollection.

• Ignores text and comment nodes.

----------------------------

childNodes

• Returns all nodes.

• Returns a NodeList.

• Includes text nodes created by spaces and line breaks.

_________________________________________________________

HTMLCollection vs NodeList

HTMLCollection

• Contains only HTML elements.

• Returned by children.

• Does not support forEach() directly.

----------------------------

NodeList

• Contains all nodes.

• Returned by childNodes.

• Supports forEach().

_________________________________________________________

Summary

✔ children returns HTML elements.

✔ childNodes returns all nodes.

✔ firstElementChild returns the first child.

✔ lastElementChild returns the last child.

✔ parentElement returns the parent.

✔ nextElementSibling returns the next sibling.

✔ children → HTMLCollection.

✔ childNodes → NodeList.

_________________________________________________________

Interview Questions

Q1. What is DOM Traversal?

Ans:

The process of navigating between elements in the DOM.

----------------------------

Q2. What does children return?

Ans:

An HTMLCollection containing only child elements.

----------------------------

Q3. What does childNodes return?

Ans:

A NodeList containing all nodes, including text and comment nodes.

----------------------------

Q4. Difference between children and childNodes?

Ans:

children

Returns only HTML elements.

childNodes

Returns all nodes including text nodes.

----------------------------

Q5. What is firstElementChild?

Ans:

Returns the first child element.

----------------------------

Q6. What is lastElementChild?

Ans:

Returns the last child element.

----------------------------

Q7. What does parentElement return?

Ans:

The parent of the selected element.

----------------------------

Q8. What does nextElementSibling return?

Ans:

The next sibling element.

Returns null if no sibling exists.

----------------------------

Q9. Why does childNodes sometimes contain more nodes than children?

Ans:

Because childNodes also includes text nodes created by spaces and line breaks in HTML.

_________________________________________________________

Easy Trick

children

↓

Only HTML Elements

----------------------------

childNodes

↓

Everything

(Element + Text + Comment)

----------------------------

parentElement

↓

Move Up ⬆

----------------------------

children

↓

Move Down ⬇

----------------------------

nextElementSibling

↓

Move Right ➡

*/